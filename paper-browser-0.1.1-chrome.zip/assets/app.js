import{c as t,j as r,r as o}from"./client.js";import{A as e}from"./App2.js";import"./politeness.js";t(document.getElementById("root")).render(r.jsx(o.StrictMode,{children:r.jsx(e,{})}));
